-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Май 06 2019 г., 09:41
-- Версия сервера: 5.6.41
-- Версия PHP: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `crm`
--

-- --------------------------------------------------------

--
-- Структура таблицы `firms`
--

CREATE TABLE `firms` (
  `firm_id` smallint(5) UNSIGNED NOT NULL,
  `firm_name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `my_firm` int(1) NOT NULL DEFAULT '0',
  `black_list` int(1) NOT NULL DEFAULT '0',
  `firm_author` int(11) DEFAULT NULL,
  `firm_comment` text CHARACTER SET utf8,
  `firm_active` tinyint(1) DEFAULT '1',
  `firm_parrent` int(11) DEFAULT NULL COMMENT 'Родительская фирма',
  `firm_full_name` text CHARACTER SET utf8 COMMENT 'Полное наименование',
  `firm_sphera` text CHARACTER SET utf8 COMMENT 'сфера деятельности фирмы',
  `firm_inn` text CHARACTER SET utf8 COMMENT 'ИНН',
  `firm_kpp` text CHARACTER SET utf8 COMMENT 'КПП',
  `firm_adress` text CHARACTER SET utf8 COMMENT 'Адрес',
  `firm_dir` text CHARACTER SET utf8 COMMENT 'фио директора',
  `firm_dir_dolgn` text NOT NULL,
  `firm_dir_opt` text CHARACTER SET utf8 COMMENT '(должность) действует на основании',
  `firm_email` text CHARACTER SET utf8 COMMENT 'емейл',
  `firm_telno` text CHARACTER SET utf8 COMMENT 'тел',
  `firm_faxno` text CHARACTER SET utf8 COMMENT 'факс',
  `firm_contacts` text CHARACTER SET utf8 COMMENT 'другие контакты',
  `firm_datetime_add` timestamp NULL DEFAULT NULL COMMENT 'время создания',
  `firm_datetime_edit` timestamp NULL DEFAULT NULL COMMENT 'время редактирования',
  `firm_author_edit` int(11) DEFAULT NULL COMMENT 'автор изменений',
  `firm_another_request` text CHARACTER SET utf8 COMMENT 'Дополнительные реквизиты'
) ENGINE=InnoDB DEFAULT CHARSET=cp1251;

--
-- Дамп данных таблицы `firms`
--

INSERT INTO `firms` (`firm_id`, `firm_name`, `my_firm`, `black_list`, `firm_author`, `firm_comment`, `firm_active`, `firm_parrent`, `firm_full_name`, `firm_sphera`, `firm_inn`, `firm_kpp`, `firm_adress`, `firm_dir`, `firm_dir_dolgn`, `firm_dir_opt`, `firm_email`, `firm_telno`, `firm_faxno`, `firm_contacts`, `firm_datetime_add`, `firm_datetime_edit`, `firm_author_edit`, `firm_another_request`) VALUES
(1, 'ООО &quot;Предприятие&quot;', 0, 0, 1, 'Комментарий.\r\nЕще и еще комментарий.', 1, 12, 'Предприятие ООО', 'Разная', '3120000000', '312000000', 'Россия', 'Иванов Иван Иванович', '', 'Доверенности № 123 от 01.01.2016', 'firma@mail.ru', '+7(4722)123-45-67', '+7(4722) 12-34-56', 'Другие \r\nконтакты', '2016-03-08 11:06:31', '2016-03-08 11:06:31', 1, 'Допо\r\nлни\r\nте\r\nльн\r\nые \r\nре\r\nквиз\r\nи\r\nты\r\n.'),
(4, 'ООО &quot;Белэнергомаш-БЗЭМ&quot;', 0, 0, 1, 'комментарий к фирме №&quot; 1', 1, 12, '', '', '', '', '', '', '', '', '', '', '', '', '2016-03-08 11:06:31', '2016-03-08 11:06:31', 1, ''),
(5, 'ОАО &quot;Белгородстройдеталь&quot;', 0, 0, 10, 'вфыаАФАаы', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '2016-03-08 11:06:31', '2016-03-08 11:06:31', NULL, NULL),
(6, 'ООО &quot;Данфосс&quot;', 0, 0, 9, 'asdasd asd asd 2', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '2016-03-08 11:06:31', '2016-03-08 11:06:31', NULL, NULL),
(7, 'ООО &quot;Агроуниверсал&quot;', 0, 0, 1, 'asdasd asd asd 2', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '2016-03-08 11:06:31', '2016-03-08 11:06:31', NULL, NULL),
(8, 'ООО &quot;ТВМ&quot;', 0, 0, 15, 'asdasd asd asd 3', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '2016-03-08 11:06:31', '2016-03-08 11:06:31', NULL, NULL),
(9, 'Фирма Фирма Фирма', 0, 0, 8, 'фирма комментарий комментарий', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '2016-03-08 11:06:31', '2016-03-08 11:06:31', NULL, NULL),
(11, 'ООО &quot;Фиasd5&quot;', 0, 0, 9, 'gfdgfg5', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '2016-03-08 11:06:31', '2016-03-08 11:06:31', NULL, NULL),
(12, 'Апельсин ОАО', 0, 0, 10, 'gdfd', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '2016-03-08 11:06:31', '2016-03-08 11:06:31', NULL, NULL),
(13, 'Совхоз Дубовое ЗАО', 0, 0, NULL, '', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '2016-03-08 11:06:31', '2016-03-08 11:06:31', NULL, NULL),
(14, 'ГУП БО &quot;Белводоканал&quot;', 0, 0, 13, '', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '2016-03-08 11:06:31', '2016-03-08 11:06:31', NULL, NULL),
(15, 'ООО &quot;АльтЭнерго&quot;', 0, 0, NULL, 'asdasdq', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '2016-03-08 11:06:31', '2016-03-08 11:06:31', NULL, NULL),
(16, 'ООО &quot;Агринко&quot;', 0, 0, NULL, '', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '2016-03-08 11:06:31', '2016-03-08 11:06:31', NULL, NULL),
(17, 'ООО &quot;Рождество Техника для ферм&quot;', 0, 0, NULL, 'фывфывыв', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '2016-03-08 11:06:31', '2016-03-08 11:06:31', NULL, NULL),
(18, 'asdfg', 0, 0, 1, '', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '2016-03-08 11:06:31', '2016-03-08 11:06:31', NULL, NULL),
(19, 'ООО Котельный завод &quot;Белэнергомаш&quot;', 0, 0, 1, '', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '2016-03-08 11:06:31', '2016-03-08 11:06:31', NULL, NULL),
(20, 'ООО &quot;Белгранкорм&quot;', 0, 0, 1, 'ирекр5', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '2016-03-08 11:06:31', '2016-03-08 11:06:31', NULL, NULL),
(21, 'ООО &quot;БСК-Белгород&quot;', 0, 0, 14, 'коммент comment', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '2016-03-08 11:06:31', '2016-03-08 11:06:31', NULL, NULL),
(22, 'ЗАО &quot;ЗУМ Белгородский&quot;', 0, 0, NULL, 'коммент', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '2016-03-08 11:06:31', '2016-03-08 11:06:31', NULL, NULL),
(23, 'АО &quot;БМК&quot;', 0, 0, 10, 'Комментарий, всякий\r\nразный\r\nмногострочный', 1, NULL, 'АО &quot;Белгородский молочный комбинат&quot;', 'Отрасль', '3123121122', '3123010101', 'РФ\r\nБелгород\r\nПривольная, 6', 'ФИО директора', 'Должность директора', 'Устава', 'qaweqe@mail.ru', '+7 4722 123-321', 'нет', 'Другие контакты\r\nфывф\r\nфывыфв', '2016-03-08 11:06:31', '2019-01-14 09:28:57', 1, 'фывфывф'),
(24, 'ООО &quot;УК Гидротех Инжиниринг&quot;', 0, 0, NULL, '112', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '2016-03-08 11:06:31', '2016-03-08 11:06:31', NULL, NULL),
(25, 'ООО &quot;Энергосервисный центр&quot;', 0, 0, 8, 'фыфв', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '2016-03-08 11:06:31', '2016-03-08 11:06:31', NULL, NULL),
(26, 'ООО &quot;Белгородские овощи&quot;', 0, 0, 3, 'фыфв', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '2016-03-08 11:06:31', '2016-03-08 11:06:31', NULL, NULL),
(29, 'ООО &quot;ТК \"Экотранс&quot;', 0, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '2016-03-08 11:06:31', '2016-03-08 11:06:31', NULL, NULL),
(42, 'АО &quot;ХК &quot;Энергомаш-Строй&quot;', 0, 0, NULL, '', 0, 23, '', '', '', '', '', '', '', '', '', '', '', '', '2016-03-08 11:06:31', '2016-03-08 11:06:31', NULL, ''),
(43, 'АО &quot;ПОЛЕМА&quot;', 0, 1, 1, '', 1, 4, 'йцву', '', '', '', '', '', '', '', 'ыуа', 'уа', '', 'вуцф', '2016-03-08 11:06:31', '2019-01-15 09:36:11', 1, 'фыв'),
(44, 'ИП Хами Кут П.А.', 0, 0, 1, 'ымкцу', 1, 23, '', '', '', '', '', '', '', '', '', '', '', 'уа', '2016-03-08 11:06:31', '2016-03-08 11:06:31', NULL, ''),
(45, 'ООО &quot;Белая птица-Белгород&quot;', 0, 1, 1, '', 1, 0, '', '', '', '', '', '', '', '', '', '', '', '', '2016-03-08 11:06:31', '2016-03-08 11:06:31', NULL, ''),
(46, 'ООО &quot;Ээ&quot;', 1, 0, 1, 'Комментарий.12\r\nЕще и еще комментар2ий.12', 1, 0, 'ЭООО', 'Разная', '3120000000', '312000000', 'Россия', 'Иванов Иван Иванович', '', 'Доверенности № 123 от 01.01.2016', 'firma@mail.ru', '+7(4722)123-45-67', '+7(4722) 12-34-56', 'Другие \r\nконтакты', '2016-03-08 11:06:31', '2016-03-08 11:06:31', 1, 'Дополнительные 13\r\nреквизиты.13'),
(48, 'Сервис', 0, 0, 1, '', 0, 0, 'ООО Сервис', '', '', '', '', '', '', '', '', '', '', '', '2016-03-08 11:06:31', '2016-09-22 11:06:31', NULL, ''),
(49, 'ООО &quot;ЭЭЭс&quot;', 1, 0, 1, '', 1, 0, 'ООО Моя компания', 'Автоматизация', '3120001122', '312301001', 'Россия', '', 'Директор', 'Устава', 'mail@site.ru', '', '', 'http://www.site.ru', '2016-03-08 11:06:31', '2019-01-15 09:35:55', 1, ''),
(50, 'ЗАО &quot;Приосколье&quot;', 0, 0, 1, 'Комментарий', 1, 50, 'ЗАО Приосколье', 'Птицефабрика', '3123100360', '311401001', 'Россия', 'Генеральный директор Кладов Александр Александрович', '', 'Устава', 'E-mail', 'Телефон', 'Факс', 'Другие контакты', '2016-03-08 11:06:31', '2018-03-08 11:06:31', 1, 'р/с 40702810507120100374 в Новооскольском ОСБ 3867 Белгородского ОСБ 8592 г Белгород,\r\nк/с 30101810100000000633\r\nБИК 041403633'),
(51, 'asfdewfsdf', 0, 0, 1, '', 0, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '2019-01-14 10:43:29', '2019-01-15 04:48:07', 0, ''),
(52, 'Наименование фирмы', 0, 0, 1, 'Комментарий', 1, NULL, 'Полное наименование', 'Отрасль', 'ИНН', 'КПП', 'Адрес', 'ФИО директора', 'Должность директора', 'Действует на основании', 'mail', 'Телефон', 'Факс', 'Другие контакты', '2019-01-14 10:44:20', '2019-01-14 10:44:20', 1, 'Реквизиты'),
(53, 'wqeqwe&quot;фыв&quot;', 0, 0, 1, 'Комментарий\r\n&quot;фыв&quot;', 1, NULL, 'qweqwewqe&quot;фыв&quot;', '234324&quot;фыв&quot;', 'r43r2&quot;фыв&quot;', '23423&quot;фыв&quot;', 'Адрес\r\n&quot;фыв&quot;', 'ФИО директора&quot;фыв&quot;', 'Должность директора&quot;фыв&quot;', 'Действует на основании:&quot;фыв&quot;', 'E-mail&quot;фыв&quot;', 'Телефон&quot;фыв&quot;', 'Факс&quot;фыв&quot;', 'Другие \r\nконтакты\r\n&quot;фыв&quot;', '2019-01-14 10:46:57', '2019-01-15 04:49:25', 1, 'Реквизиты\r\n&quot;фыв&quot;'),
(54, 'ООО &quot;РЕКОМ&quot;', 0, 0, 1, '', 1, NULL, 'ООО &quot;РЕКОМ&quot;', '', '', '', '', 'Череватюк Евгений', 'Директор', '', 'info@rekom.su', '+7 (473) 228-60-69', '', 'Евгений Череватюк,\r\n \r\nООО &quot;РЕКОМ&quot;\r\nTel: +7-(473)-228-60-69\r\nMob: +7-950-715-69-44\r\nE-Mail: info@rekom.su\r\nWeb: www.rekom.su', '2019-01-15 10:18:26', '2019-01-15 10:18:26', 1, ''),
(55, 'ООО &quot;Силариус&quot;', 0, 0, 1, '', 1, NULL, 'ООО &quot;Силариус&quot;', '', '5501256355', '550101001', '644083, г.Омск, ул. Бородина\r\nд.6, пом. 1П', 'Еремин Николай Николаевич', '', 'Устава', 'silarius@mail.ru', '8-(3812)999-527', '8-(3812)999-527', '', '2019-01-17 05:31:52', '2019-01-17 05:31:52', 1, 'Реквизиты организации\r\n№\r\nП/П Наименование Сведения\r\n1. Фирменное наименование Силариус\r\n2 Организационно-правовая форма ООО\r\n3 Место нахождения (юридический адрес) 644083, г.Омск, ул. Бородина\r\nд.6, пом. 1П\r\n4 Почтовый адрес (фактический адрес) 644083, г.Омск, ул. Бородина\r\nд.6, пом. 1П\r\n5 ОГРН 1145543011338\r\n6 ИНН 5501256355\r\n7 КПП 550101001\r\n8 ОКПО 23683303\r\n9 ОКАТО 52401380000\r\n10 ОКТМО 52701000001\r\n11 ОКВЭД 51.43, 51.53, 51.54, 51.65,\r\n51.70, 74.13, 74.84, 93.05\r\n12 р/с 40702810404000008012\r\n13 Банк\r\nСибирский филиал ПАО\r\n«Промсвязьбанк», г.\r\nНовосибирск.\r\nОперационный офис ПАО\r\n«Промсвязьбанк» в г.Омск по\r\nадресу Газетный переулок. -\r\nугол ул. К. Либкнехта, д. 8/24\r\n14 к/сч 30101810500000000816\r\n15 БИК 045004816\r\n16 Руководитель (должность, Ф.И.О.) Еремин Николай Николаевич\r\n17\r\nДокумент, подтверждающий полномочия при подписании\r\nдоговора\r\nустав\r\n18 Тел/факс 8-(3812)999-527\r\n19 E-mail silarius@mail.ru'),
(56, 'ОАО &quot;Завод ЖБК-1&quot;', 0, 0, 1, '', 1, NULL, 'ОАО &quot;Завод ЖБК-1&quot;', '', '', '', '308013, г. Белгород, ул. Коммунальная, 5', '', '', '', '', '(4722) 21-56-14', '(4722) 21-56-14', '', '2019-01-23 04:42:14', '2019-01-23 04:42:14', 1, '');

-- --------------------------------------------------------

--
-- Структура таблицы `messages`
--

CREATE TABLE `messages` (
  `mess_id` int(11) NOT NULL,
  `mess_active` int(11) DEFAULT '1',
  `mess_datetime` timestamp NULL DEFAULT NULL,
  `mess_author` int(11) DEFAULT NULL,
  `mess_firm` int(11) DEFAULT NULL,
  `mess_project` int(11) DEFAULT NULL,
  `mess_text` text,
  `mess_datetime_edit` timestamp NULL DEFAULT NULL,
  `mess_author_edit` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `messages`
--

INSERT INTO `messages` (`mess_id`, `mess_active`, `mess_datetime`, `mess_author`, `mess_firm`, `mess_project`, `mess_text`, `mess_datetime_edit`, `mess_author_edit`) VALUES
(92, 1, '2016-03-22 05:28:43', 4, 3, 3, '1 update top(10) tbl_books set price = 0 where quantity = 0;\r\n 2 \r\n', '2016-03-31 12:54:32', 1),
(93, 1, '2016-03-22 05:28:48', 2, 4, 6, 'as', '2016-03-30 08:38:59', 1),
(94, 1, '2016-03-22 05:28:49', 4, 4, 3, 'sssssssssssss', NULL, NULL),
(95, 1, '2016-03-22 05:28:50', 1, 5, 4, 'aaaaaaaaa', NULL, NULL),
(96, 1, '2016-03-22 05:31:04', 7, 12, 5, 'as', '2016-04-01 09:21:30', 1),
(97, 1, '2016-03-22 05:35:23', 4, 15, 6, 'as&quot;&quot;&quot;s', '2016-03-30 09:47:37', 1),
(98, 1, '2016-03-22 05:37:31', 3, 4, 6, '&lt;!DOCTYPE HTML&gt;\r\n&lt;html&gt;\r\n &lt;head&gt;\r\n  &lt;meta charset=&quot;utf-8&quot;&gt;\r\n  &lt;title&gt;Тег P&lt;/title&gt;\r\n &lt;/head&gt;\r\n &lt;body&gt;\r\n\r\n  &lt;p&gt;Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diem \r\n  nonummy nibh euismod tincidunt ut lacreet dolore magna aliguam erat volutpat.&lt;/p&gt;\r\n  &lt;p&gt;Ut wisis enim ad minim veniam, quis nostrud exerci tution ullamcorper \r\n  suscipit lobortis nisl ut aliquip ex ea commodo consequat.&lt;/p&gt;\r\n\r\n &lt;/body&gt;\r\n&lt;/html&gt;', '2016-03-30 09:45:31', 1),
(99, 1, '2016-03-30 07:33:02', 1, 4, 6, 'top(x) — команда выполнится только х раз\r\n<объект> — объект, над которым выполняется действие (таблица или представление)\r\n<присваивание> — присваивание, которое будет выполняться при каждом выполнении условия <условие>, или для каждой записи, если отсутствует раздел where\r\n<условие> — условие выполнения команды\r\nSET — после ключевого слова должен идти список полей таблицы, которые будут обновлены и непосредственно сами новые значения в виде\r\nимя поля=\"значение\"', '2016-03-30 09:24:19', 1),
(100, 1, '2016-03-30 07:34:21', 1, 4, 3, 'На какие электроустановки распространяются требования Правил устройства электроустановок?\r\nОтвет	Результат\r\nТолько на электроустановки переменного тока напряжением до 380 кВ	Неправильный ответ \r\nНа вновь сооружаемые и реконструируемые электроустановки постоянного и переменного тока напряжением до 750 кВ, в том числе на специальные электроустановки	Правильный ответ \r\nНа сооружаемые электроустановки постоянного и переменного тока напряжением до 750 кВ	Неправильный ответ \r\nНа все электроустановки	Неправильный ответ \r\n', '2016-03-30 09:21:50', 4),
(101, 1, '2016-03-30 09:50:34', 1, 23, 3, 'В HTML некоторые символы имеют особый смысл и должны быть представлены в виде HTML сущностей, чтобы сохранить их значение. Эта функция возвращает строку, над которой проведены эти преобразования. Если вам нужно преобразовать все возможные сущности, используйте htmlentities().\r\n\r\nЕсли входная строка переданная в эту функцию и результирующий документ используют одинаковую кодировку символов, то этой функции достаточно, чтобы подготовить данные для вставки в большинство частей HTML документа. Однако, если данные содержат символы, не определенные в кодировке символов результирующего документа и вы ожидаете сохранения этих символов (как числовые или именованные сущности), то вам недостаточно будет этой и htmlentities() функций (которые только преобразуют подстроки с соответствующими сущностями). Необходимо использовать функцию mb_encode_numericentity().\r\n\r\nПроизводятся следующие преобразования:\r\n\r\n\'&amp;\' (амперсанд) преобразуется в \'&amp;amp;\'\r\n\'&quot;\' (двойная кавычка) преобразуется в \'&amp;quot;\' в режиме ENT_NOQUOTES is not set.\r\n&quot;\'&quot; (одиночная кавычка) преобразуется в \'&amp;#039;\' (или &amp;apos;) только в режиме ENT_QUOTES.\r\n\'&lt;\' (знак &quot;меньше чем&quot;) преобразуется в \'&amp;lt;\'\r\n\'&gt;\' (знак &quot;больше чем&quot;) преобразуется в \'&amp;gt;\'', NULL, NULL),
(102, 1, '2016-03-30 09:54:29', 1, 22, 5, 'Etc/GMT-3', NULL, NULL),
(103, 1, '2016-03-30 12:21:46', 1, 22, 15, 'сыф ыф ыф', NULL, NULL),
(104, 1, '2016-03-31 05:11:46', 1, 23, 3, 'cxvcx', NULL, NULL),
(105, 1, '2016-03-31 05:28:04', 1, 5, 4, 'qwe', NULL, NULL),
(106, 1, '2016-03-31 05:29:27', 1, 4, 4, '123', NULL, NULL),
(107, 1, '2016-03-31 07:16:43', 1, 4, 5, 'qweqw1112', NULL, NULL),
(108, 1, '2016-03-31 12:41:01', 1, 43, 3, '123', '2016-03-31 13:04:56', 1),
(109, 0, '2016-03-31 12:42:09', 1, 1, 3, '123', NULL, NULL),
(110, 0, '2016-03-31 12:42:28', 1, 1, 3, '', NULL, NULL),
(111, 0, '2016-03-31 12:45:27', 1, 4, 4, '123ewq', NULL, NULL),
(112, 1, '2016-03-31 12:49:35', 1, 4, 5, 'wefrewfwef', NULL, NULL),
(113, 1, '2016-03-31 12:50:16', 1, 22, 15, 'asdsad', NULL, NULL),
(114, 1, '2016-03-31 12:50:33', 1, 42, 6, 'qwdsa1', NULL, NULL),
(115, 1, '2016-03-31 12:50:57', 1, 8, 0, '12e', '2016-03-31 13:11:15', 1),
(116, 1, '2016-03-31 13:30:48', 1, 11, 12, 'asdasd', NULL, NULL),
(117, 1, '2016-04-01 05:18:57', 1, 4, 8, 'sdadas', NULL, NULL),
(118, 1, '2016-04-01 05:19:08', 1, 23, 0, 'asdsad', '2016-04-01 09:19:08', 1),
(119, 1, '2016-04-01 05:19:14', 1, 4, 11, 'asdsadqed23ed', NULL, NULL),
(120, 1, '2016-04-01 05:19:47', 1, 4, 21, 'gderr', NULL, NULL),
(121, 1, '2016-04-01 12:51:28', 1, 13, 15, 'Можно ли настроить систему, чтобы сайты, расположенные на локальном компьютере, были доступны всем пользователям локальной сети, к которой я подключен, или же даже из Интернета?..\r\n\r\nПроекты, заведенные в Денвере, по умолчанию не доступны из локальной сети. Это достигается благодаря тому, что все виртуальные хосты имеют IP-адрес 127.0.0.1, всегда обозначающий &quot;текущая локальная машина&quot;.\r\n\r\nТем не менее, все же существует возможность назначить тому или иному виртуальному хосту &quot;внешний&quot; IP-адрес, доступный из вашей локальной сети или даже Интернета (если компьютер имеет постоянный IP-адрес в Интернете).\r\n\r\nПомните: Денвер - это инструмент разработчика, а не средство хостинга. Несмотря на то, что проекты в Денвере можно открыть для всеобщего доступа, мы категорически не рекомендуем это делать. Дело тут в безопасности: Денвер, как правило, запускается с правами Администратора, а значит, скрипты, запущенные под его управлением, могут делать на машине все, что угодно. Малейшая &quot;дыра&quot; в безопасности скрипта откроет хакеру доступ к вашей машине. \r\n\r\nАвторы Денвера не несут ответственности за любые разрушения, причиненные хакерами тем, кто открыл Денвер наружу и по неосторожности допустил в своих скриптах уязвимость в безопасности.', NULL, NULL),
(122, 1, '2016-04-01 13:12:28', 1, 45, 23, 'Тестовое сообщение.\r\nНа нескольких строках.', NULL, NULL),
(123, 1, '2016-04-01 13:20:51', 1, 4, 8, 'Такой код быстро пишется, также быстро выполняется, и, по мере роста вашего приложения, становится совершенно неподдерживаемым. Таким образом, тут имеется несколько проблем, которые требуется решить:\r\n\r\nНет обработчика ошибок: А что, если подключение к базе данных отвалится?\r\nПлохая организация кода: По мере роста приложения, этот файл будет все больше и больше, в то же время поддерживать его будет всё сложнее и сложнее. Где вы должны будете разместить код, который обрабатывает отправку формы? Как вы будете проверять входные данные? А куда разместить код для отправки email’ов?\r\nСложность (а скорее даже невозможность) повторного использования кода: Так как весь код располагается в одном файле, нет никакой возможности повторного использования любой части приложения для других страниц блога.', NULL, NULL),
(124, 1, '2016-04-04 10:01:48', 1, 22, 15, 'Новое сообщение', NULL, NULL),
(125, 1, '2016-04-04 10:03:54', 1, 22, 15, 'фывфывфы', NULL, NULL),
(126, 1, '2016-04-04 10:04:44', 1, 22, 15, 'ффы', NULL, NULL),
(127, 1, '2016-04-04 10:05:43', 1, 22, 15, 'ц12у', NULL, NULL),
(128, 1, '2016-04-04 11:16:18', 1, 22, 15, 'ьрпмори', NULL, NULL),
(129, 1, '2016-04-04 11:17:52', 1, 5, 21, 'орб', NULL, NULL),
(130, 1, '2016-04-04 11:18:21', 1, 12, 22, 'лорлбт', NULL, NULL),
(131, 1, '2016-04-04 11:18:36', 1, 45, 23, 'дго89нр', NULL, NULL),
(132, 1, '2016-04-04 13:06:20', 1, 12, 0, 'Пкарлдопм', NULL, NULL),
(133, 1, '2016-04-04 13:06:28', 1, 12, 0, 'фывафыва423', NULL, NULL),
(134, 1, '2016-04-04 13:10:51', 1, 13, 16, 'ыа 4ука 43', NULL, NULL),
(135, 1, '2017-03-27 10:34:42', 1, 50, 3, 'hhg,jhg,jhbhjb mjh vjh vj vbm', NULL, NULL),
(136, 1, '2018-11-30 09:27:30', 1, NULL, 23, '12', NULL, NULL),
(137, 1, '2018-11-30 09:29:55', 1, NULL, 23, '21', NULL, NULL),
(138, 1, '2018-11-30 09:33:14', 1, NULL, 23, '', NULL, NULL),
(139, 1, '2018-11-30 09:34:15', 1, NULL, 23, '', NULL, NULL),
(140, 1, '2018-11-30 09:34:20', 1, NULL, 23, '', NULL, NULL),
(141, 1, '2018-11-30 09:34:54', 1, NULL, 22, '', NULL, NULL),
(142, 1, '2018-11-30 09:35:40', 1, NULL, 22, '', NULL, NULL),
(143, 1, '2018-11-30 09:37:20', 1, NULL, 23, '123', NULL, NULL),
(144, 1, '2018-11-30 09:37:48', 1, NULL, 23, '&lt;?php\r\n$date = DateTime::createFromFormat(\'j-M-Y\', \'15-Feb-2009\');\r\necho $date-&gt;format(\'Y-m-d\');\r\n?&gt;', NULL, NULL),
(145, 1, '2018-11-30 09:43:19', 1, NULL, 23, 'meric\'=&gt;Array(\'min_byte\'=&gt;2, \'max_byte\'=&gt;67, \'byte_formula\'=&gt;\'D==0?(M+1):(M+2)\', \'length\'=&gt;65),\r\n', NULL, NULL),
(146, 1, '2018-11-30 09:43:32', 1, NULL, 23, 'meric\'=&gt;Array(\'min_byte\'=&gt;2, \'max_byte\'=&gt;67, \'byte_formula\'=&gt;\'D==0?(M+1):(M+2)\', \'length\'=&gt;65),\r\n   \r\n   // FLOAT DOUBLE  \r\n ', NULL, NULL),
(147, 1, '2018-11-30 09:45:18', 1, NULL, 23, '1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n', NULL, NULL),
(148, 1, '2018-11-30 09:45:49', 1, NULL, 23, '1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n', NULL, NULL),
(149, 1, '2018-11-30 09:46:02', 1, NULL, 23, '1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n1\r\n', NULL, NULL),
(150, 1, '2018-11-30 09:53:57', 1, NULL, 23, 'switch ($op)  \r\n	{  \r\n        case \'main\' : include &quot;main.php&quot;; break;  \r\n		case \'archive\' : include &quot;archive.php&quot;; break;  \r\n		case \'search\' : include &quot;search.php&quot;; break;  \r\n        case \'del\' : include &quot;del.php&quot;; break;  \r\n        case \'edit\' : include &quot;edit.php&quot;; break;  \r\n		case \'messadd\' : include &quot;action.php&quot;; break;  \r\n        case \'add\' : include &quot;add.php&quot;; break;  \r\n        case \'show\' : include &quot;show.php&quot;; break;  \r\n        default :  include &quot;main.php&quot;;  \r\n	}  \r\n\r\n				}', NULL, NULL),
(151, 1, '2018-11-30 09:54:55', 1, NULL, 23, 'string htmlspecialchars ( string $string [, int $flags = ENT_COMPAT | ENT_HTML401 [, string $encoding = ini_get(&quot;default_charset&quot;) [, bool $double_encode = TRUE ]]] )string htmlspecialchars ( string $string [, int $flags = ENT_COMPAT | ENT_HTML401 [, string $encoding = ini_get(&quot;default_charset&quot;) [, bool $double_encode = TRUE ]]] )string htmlspecialchars ( string $string [, int $flags = ENT_COMPAT | ENT_HTML401 [, string $encoding = ini_get(&quot;default_charset&quot;) [, bool $double_encode = TRUE ]]] )string htmlspecialchars ( string $string [, int $flags = ENT_COMPAT | ENT_HTML401 [, string $encoding = ini_get(&quot;default_charset&quot;) [, bool $double_encode = TRUE ]]] )string htmlspecialchars ( string $string [, int $flags = ENT_COMPAT | ENT_HTML401 [, string $encoding = ini_get(&quot;default_charset&quot;) [, bool $double_encode = TRUE ]]] )string htmlspecialchars ( string $string [, int $flags = ENT_COMPAT | ENT_HTML401 [, string $encoding = ini_get(&quot;default_charset&quot;) [, bool $double_encode = TRUE ]]] )string htmlspecialchars ( string $string [, int $flags = ENT_COMPAT | ENT_HTML401 [, string $encoding = ini_get(&quot;default_charset&quot;) [, bool $double_encode = TRUE ]]] )string htmlspecialchars ( string $string [, int $flags = ENT_COMPAT | ENT_HTML401 [, string $encoding = ini_get(&quot;default_charset&quot;) [, bool $double_encode = TRUE ]]] )string htmlspecialchars ( string $string [, int $flags = ENT_COMPAT | ENT_HTML401 [, string $encoding = ini_get(&quot;default_charset&quot;) [, bool $double_encode = TRUE ]]] )string htmlspecialchars ( string $string [, int $flags = ENT_COMPAT | ENT_HTML401 [, string $encoding = ini_get(&quot;default_charset&quot;) [, bool $double_encode = TRUE ]]] )string htmlspecialchars ( string $string [, int $flags = ENT_COMPAT | ENT_HTML401 [, string $encoding = ini_get(&quot;default_charset&quot;) [, bool $double_encode = TRUE ]]] )string htmlspecialchars ( string $string [, int $flags = ENT_COMPAT | ENT_HTML401 [, string $encoding = ini_get(&quot;default_charset&quot;) [, bool $double_encode = TRUE ]]] )string htmlspecialchars ( string $string [, int $flags = ENT_COMPAT | ENT_HTML401 [, string $encoding = ini_get(&quot;default_charset&quot;) [, bool $double_encode = TRUE ]]] )string htmlspecialchars ( string $string [, int $flags = ENT_COMPAT | ENT_HTML401 [, string $encoding = ini_get(&quot;default_charset&quot;) [, bool $double_encode = TRUE ]]] )string htmlspecialchars ( string $string [, int $flags = ENT_COMPAT | ENT_HTML401 [, string $encoding = ini_get(&quot;default_charset&quot;) [, bool $double_encode = TRUE ]]] )', NULL, NULL),
(152, 1, '2018-11-30 09:59:22', 1, NULL, 23, 'ыфв', NULL, NULL),
(153, 1, '2018-11-30 10:01:52', 1, NULL, 23, 'фывфыв', NULL, NULL),
(154, 1, '2018-11-30 10:02:05', 1, NULL, 23, '\r\n	\r\nЗдравствуйте, admin!\r\n\r\nГлавнаяПроектыПредприятияПользователиВыход\r\n\r\n\r\n23. asdfsdvfdsv\r\n\r\nПредприятие заказчик	Предприятие ООО\r\nПредприятие исполнитель	Совхоз Дубовое ЗАО\r\nАвтор проекта	admin\r\nОтветственный	Сидоров Сидор Петрович\r\nДата регистрации	2016-03-23 10:38:41\r\nСрок выполнения	0000-00-00 00:00:00\r\nДата завершения	\r\nТип проекта	0\r\nДата полного расчета	\r\nДата получения актов вып. работ	\r\nСтатус проекта	\r\nКомментарий	ssssssssss\r\nДобавить сообщение\r\nЗапись:\r\n\r\nasdasd\r\n\r\n\r\nCообщения проекта\r\n\r\nadmin 01.04.2016 16:12\r\nТестовое сообщение. На нескольких строках.\r\n\r\n\r\nadmin 04.04.2016 14:18\r\nдго89нр\r\n\r\n\r\nadmin 30.11.2018 12:27\r\n12\r\n\r\n\r\nadmin 30.11.2018 12:29\r\n21\r\n\r\n\r\nadmin 30.11.2018 12:33\r\n\r\nadmin 30.11.2018 12:34\r\n\r\nadmin 30.11.2018 12:34\r\n\r\nadmin 30.11.2018 12:37\r\n123\r\n\r\n\r\nadmin 30.11.2018 12:37\r\n&lt;?php $date = DateTime::createFromFormat(\'j-M-Y\', \'15-Feb-2009\'); echo $date-&gt;format(\'Y-m-d\'); ?&gt;\r\n\r\n\r\nadmin 30.11.2018 12:43\r\nmeric\'=&gt;Array(\'min_byte\'=&gt;2, \'max_byte\'=&gt;67, \'byte_formula\'=&gt;\'D==0?(M+1):(M+2)\', \'length\'=&gt;65),\r\n\r\n\r\nadmin 30.11.2018 12:43\r\nmeric\'=&gt;Array(\'min_byte\'=&gt;2, \'max_byte\'=&gt;67, \'byte_formula\'=&gt;\'D==0?(M+1):(M+2)\', \'length\'=&gt;65), // FLOAT DOUBLE\r\n\r\n\r\nadmin 30.11.2018 12:45\r\n1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1\r\n\r\n\r\nadmin 30.11.2018 12:45\r\n1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1\r\n\r\n\r\nadmin 30.11.2018 12:46\r\n1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1\r\n\r\n\r\nadmin 30.11.2018 12:53\r\nswitch ($op) { case \'main\' : include &quot;main.php&quot;; break; case \'archive\' : include &quot;archive.php&quot;; break; case \'search\' : include &quot;search.php&quot;; break; case \'del\' : include &quot;del.php&quot;; break; case \'edit\' : include &quot;edit.php&quot;; break; case \'messadd\' : include &quot;action.php&quot;; break; case \'add\' : include &quot;add.php&quot;; break; case \'show\' : include &quot;show.php&quot;; break; default : include &quot;main.php&quot;; } }\r\n\r\n\r\nadmin 30.11.2018 12:54\r\nstring htmlspecialchars ( string $string [, int $flags = ENT_COMPAT | ENT_HTML401 [, string $encoding = ini_get(&quot;default_charset&quot;) [, bool $double_encode = TRUE ]]] )string htmlspecialchars ( string $string [, int $flags = ENT_COMPAT | ENT_HTML401 [, string $encoding = ini_get(&quot;default_charset&quot;) [, bool $double_encode = TRUE ]]] )string htmlspecialchars ( string $string [, int $flags = ENT_COMPAT | ENT_HTML401 [, string $encoding = ini_get(&quot;default_charset&quot;) [, bool $double_encode = TRUE ]]] )string htmlspecialchars ( string $string [, int $flags = ENT_COMPAT | ENT_HTML401 [, string $encoding = ini_get(&quot;default_charset&quot;) [, bool $double_encode = TRUE ]]] )string htmlspecialchars ( string $string [, int $flags = ENT_COMPAT | ENT_HTML401 [, string $encoding = ini_get(&quot;default_charset&quot;) [, bool $double_encode = TRUE ]]] )string htmlspecialchars ( string $string [, int $flags = ENT_COMPAT | ENT_HTML401 [, string $encoding = ini_get(&quot;default_charset&quot;) [, bool $double_encode = TRUE ]]] )string htmlspecialchars ( string $string [, int $flags = ENT_COMPAT | ENT_HTML401 [, string $encoding = ini_get(&quot;default_charset&quot;) [, bool $double_encode = TRUE ]]] )string htmlspecialchars ( string $string [, int $flags = ENT_COMPAT | ENT_HTML401 [, string $encoding = ini_get(&quot;default_charset&quot;) [, bool $double_encode = TRUE ]]] )string htmlspecialchars ( string $string [, int $flags = ENT_COMPAT | ENT_HTML401 [, string $encoding = ini_get(&quot;default_charset&quot;) [, bool $double_encode = TRUE ]]] )string htmlspecialchars ( string $string [, int $flags = ENT_COMPAT | ENT_HTML401 [, string $encoding = ini_get(&quot;default_charset&quot;) [, bool $double_encode = TRUE ]]] )string htmlspecialchars ( string $string [, int $flags = ENT_COMPAT | ENT_HTML401 [, string $encoding = ini_get(&quot;default_charset&quot;) [, bool $double_encode = TRUE ]]] )string htmlspecialchars ( string $string [, int $flags = ENT_COMPAT | ENT_HTML401 [, string $encoding = ini_get(&quot;default_charset&quot;) [, bool $double_encode = TRUE ]]] )string htmlspecialchars ( string $string [, int $flags = ENT_COMPAT | ENT_HTML401 [, string $encoding = ini_get(&quot;default_charset&quot;) [, bool $double_encode = TRUE ]]] )string htmlspecialchars ( string $string [, int $flags = ENT_COMPAT | ENT_HTML401 [, string $encoding = ini_get(&quot;default_charset&quot;) [, bool $double_encode = TRUE ]]] )string htmlspecialchars ( string $string [, int $flags = ENT_COMPAT | ENT_HTML401 [, string $encoding = ini_get(&quot;default_charset&quot;) [, bool $double_encode = TRUE ]]] )\r\n\r\n\r\nadmin 30.11.2018 12:59\r\nыфв\r\n\r\n\r\nadmin 30.11.2018 13:01\r\nфывфыв\r\n\r\n\r\nПоиск\r\n \r\n\r\nНовый проект\r\n\r\nАрхивные\r\n\r\nCRM v 2.1 (c) powered by AS 2016-2017', NULL, NULL),
(155, 1, '2018-11-30 10:04:33', 2, NULL, 23, 'Новая запись', NULL, NULL),
(156, 1, '2018-11-30 10:04:46', 2, NULL, 23, 'И еще одна', NULL, NULL),
(157, 1, '2018-11-30 10:25:42', 1, NULL, 3, 'фавыав', NULL, NULL),
(158, 1, '2018-11-30 10:27:09', 1, NULL, 11, 'Новая запись по этому проекту.\r\nНичего необычного, просто текст.', NULL, NULL),
(159, 1, '2018-11-30 10:34:29', 1, NULL, 5, '213', NULL, NULL),
(160, 1, '2018-11-30 10:44:36', 1, NULL, 3, 'lkjhi7рш7е', NULL, NULL),
(161, 1, '2018-11-30 10:44:49', 1, NULL, 12, 'Обновим', NULL, NULL),
(162, 1, '2018-11-30 10:57:12', 1, NULL, 23, 'Запись в проект', NULL, NULL),
(163, 1, '2018-12-03 12:27:37', 1, NULL, 23, 'fdgbdfkgfdg', NULL, NULL),
(164, 1, '2018-12-04 06:52:36', 1, NULL, 23, 'фыв', NULL, NULL),
(165, 1, '2018-12-04 06:52:42', 1, NULL, 23, 'фыва', NULL, NULL),
(166, 1, '2018-12-04 06:54:09', 1, NULL, 23, 'йцуйцуу', NULL, NULL),
(167, 1, '2018-12-05 06:37:59', 1, NULL, 3, '123', NULL, NULL),
(168, 1, '2018-12-05 06:38:33', 1, NULL, 3, '1233', NULL, NULL),
(169, 1, '2018-12-05 12:32:58', 1, NULL, 29, 'Выставил КП 788.', NULL, NULL),
(170, 1, '2018-12-13 10:55:22', 1, NULL, 32, 'nmbnmb m', NULL, NULL),
(171, 1, '2018-12-13 10:55:31', 1, NULL, 32, 'орпораорадо', NULL, NULL),
(172, 1, '2018-12-19 13:03:28', 1, NULL, 22, '1', NULL, NULL),
(173, 1, '2018-12-26 12:03:01', 1, NULL, 55, 'Прозвон клиенту. Не берет трубку.', NULL, NULL),
(174, 1, '2018-12-28 09:05:30', 1, NULL, 22, 'gfhfhfgh', NULL, NULL),
(175, 1, '2018-12-29 08:25:27', 1, NULL, 22, 'длопдлрапрлди апа', NULL, NULL),
(176, 1, '2018-12-29 08:30:23', 1, NULL, 56, 'запросили у него реквизиты', NULL, NULL),
(177, 1, '2019-01-09 09:55:33', 1, NULL, 57, 'Подходят такие \r\nCode No.	\r\n176F3164\r\nHeatsink Fan DC 172x51\r\nEAN	\r\n5710107600946', NULL, NULL),
(178, 1, '2019-01-09 09:56:48', 1, NULL, 57, '293,87	 40,0%	есть на складе', NULL, NULL),
(179, 1, '2019-01-09 10:41:59', 1, NULL, 57, 'Выставлено КП 803.', NULL, NULL),
(180, 1, '2019-01-15 04:51:57', 1, NULL, 57, 'фыа\r\n\r\n&quot;фыв&quot;', NULL, NULL),
(181, 1, '2019-01-15 07:41:43', 1, NULL, 55, 'Нет связи', NULL, NULL),
(182, 1, '2019-01-15 10:28:20', 1, NULL, 59, 'Предложил FC-102.\r\nВыставил КП 805.\r\n', NULL, NULL),
(183, 1, '2019-01-15 10:29:15', 1, NULL, 59, '131F5451\r\nПреобразователь частоты FC-102 37 кВт \r\nFC-102P37KT4E20H2XGXXXXSXXXXAXBXCXXXXDX	\r\nЦена 174 178,00\r\nСрок 4-5 недель\r\n', NULL, NULL),
(184, 1, '2019-01-15 10:32:07', 1, NULL, 59, 'Lenze стоит ESV373N04TXB 178 072 руб.\r\nhttps://www.ruselkom.ru/chastotnye-preobrazovateli/esv373n04txb/', NULL, NULL),
(185, 1, '2019-01-15 11:23:02', 1, NULL, 59, 'Ответ клиента:\r\nСпасибо, Александр.\r\nЦена более-менее конкурентная.\r\nФормируем клиенту стоимость, как только\r\nбудет ответ по датам - дополнительно сообщим.', NULL, NULL),
(186, 1, '2019-01-18 05:23:16', 1, NULL, 60, 'Выставлено КПн806', NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `product_name` text NOT NULL,
  `product_group` int(11) NOT NULL,
  `product_active` int(11) NOT NULL DEFAULT '1',
  `product_comment` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `products`
--

INSERT INTO `products` (`product_id`, `product_name`, `product_group`, `product_active`, `product_comment`) VALUES
(1, 'Advanced Control ADV 0.40 C220-M преобразователь частоты 0.4кВт, 2.3А 220В (1 фаза)', 1, 1, ''),
(2, 'Advanced Control ADV 0.75 C220-M преобразователь частоты 0.75кВт, 4.0А 220В (1 фаза)', 1, 1, ''),
(3, 'Advanced Control ADV 1.50 C220-M преобразователь частоты 1.5кВт, 7.0А 220В (1 фаза)', 1, 1, ''),
(4, 'Ghjlern4', 0, 0, ''),
(5, 'SSI устройство плавного пуска 123123', 2, 1, ''),
(6, 'jjjj', 1, 0, ''),
(7, 'asdasd', 3, 1, 'asdasd1111');

-- --------------------------------------------------------

--
-- Структура таблицы `products_group`
--

CREATE TABLE `products_group` (
  `group_id` int(11) NOT NULL,
  `product_group_name` text NOT NULL,
  `product_group_active` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `products_group`
--

INSERT INTO `products_group` (`group_id`, `product_group_name`, `product_group_active`) VALUES
(1, 'Преобразователи частоты', 1),
(2, 'Устройства плавного пуска', 1),
(3, 'фывфыв', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `projects`
--

CREATE TABLE `projects` (
  `pr_id` int(11) NOT NULL,
  `pr_active` int(1) DEFAULT '1' COMMENT 'Проект активен/удален',
  `pr_name` text NOT NULL COMMENT 'Название проекта',
  `pr_firm` int(11) DEFAULT NULL COMMENT 'Заказчик',
  `pr_author` int(11) DEFAULT NULL COMMENT 'Кто создал проект',
  `pr_lid` int(11) DEFAULT NULL COMMENT 'Ответственный',
  `pr_date_reg` date DEFAULT NULL COMMENT 'Дата регистрации проекта',
  `pr_date_limit` date DEFAULT NULL COMMENT 'Срок выполнения проекта',
  `pr_date_finish` date DEFAULT NULL COMMENT 'Дата завершения проекта',
  `pr_type` int(11) DEFAULT NULL COMMENT 'Тип проекта',
  `pr_date_cost` date DEFAULT NULL COMMENT 'Дата полного расчета',
  `pr_date_acts` date DEFAULT NULL COMMENT 'Дата получения актов',
  `pr_date_get_acts` date NOT NULL,
  `pr_status` int(11) DEFAULT NULL COMMENT 'Статус проекта',
  `pr_performer` int(11) DEFAULT NULL COMMENT 'Исполнитель проекта',
  `pr_comment` text COMMENT 'Комментарий к проекту',
  `pr_update` timestamp NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `projects`
--

INSERT INTO `projects` (`pr_id`, `pr_active`, `pr_name`, `pr_firm`, `pr_author`, `pr_lid`, `pr_date_reg`, `pr_date_limit`, `pr_date_finish`, `pr_type`, `pr_date_cost`, `pr_date_acts`, `pr_date_get_acts`, `pr_status`, `pr_performer`, `pr_comment`, `pr_update`) VALUES
(3, 1, 'ПЕРВЫЙ ТЕСТОВЫЙ ПРОЕКТ МОДЕРНИЗАЦИИ КАКОГО-ЛИБО ПРОМЫШЛЕННОГО ОБОРУДОВАНИЯ', 4, 1, 1, '2016-03-03', '2016-03-26', '2017-03-21', 0, '0000-00-00', '0000-00-00', '0000-00-00', 1, 46, 'комм', '2018-12-05 10:17:45'),
(4, 1, 'Второй пробный проект', 15, 3, 4, '2016-03-08', '2016-03-25', '0000-00-00', 0, '0000-00-00', '0000-00-00', '0000-00-00', 2, 49, 'sadыфвафы21', '2018-12-04 11:50:55'),
(5, 1, 'Третий проект', 15, 1, 1, '2016-03-04', '2016-03-31', '0000-00-00', 0, '0000-00-00', '0000-00-00', '0000-00-00', 8, 49, 'фыв фыв\r\nфывфыв', '2018-12-14 12:51:32'),
(6, 1, 'вфыв2', 11, 1, 7, '2016-03-14', '2016-03-17', NULL, 321, NULL, NULL, '0000-00-00', 4, 46, 'цйуцй йцуйцу\r\nй3у 23', '2018-11-30 10:25:42'),
(7, 1, 'фывыавывфа', 12, 1, 10, '2016-03-10', '2016-03-28', NULL, 1, NULL, NULL, '0000-00-00', 5, 0, '', '2018-11-30 10:25:42'),
(8, 1, 'Первый тестовый проект', 4, 1, 9, '2016-03-16', '2016-03-25', NULL, 2, NULL, NULL, '0000-00-00', 6, 49, 'Ко\r\nмм\r\nен\r\nта\r\nрий', '2018-11-30 10:25:42'),
(9, 1, 'Второй тестовый проект', 22, 1, 5, '2016-03-16', '2016-03-31', NULL, 1, NULL, NULL, '0000-00-00', 7, 0, '', '2018-11-30 10:25:42'),
(10, 1, 'Проект модернизации какого-либо станка', 29, 1, 5, '2016-03-16', '2016-03-30', NULL, 1, NULL, NULL, '0000-00-00', 8, 0, '', '2018-11-30 10:25:42'),
(11, 1, 'Проект модернизации системы термометрии', 29, 1, 1, '2016-03-16', '2016-03-30', NULL, 1, NULL, NULL, '0000-00-00', 9, 46, '', '2018-11-30 10:25:42'),
(12, 1, 'Поставка оборудования', 24, 1, 1, '2016-03-16', '2016-03-30', '0000-00-00', 0, '0000-00-00', '0000-00-00', '0000-00-00', 7, 46, '', '2018-12-14 06:08:37'),
(13, 1, 'Проект понедельника', 8, 1, 1, '2016-03-21', '0000-00-00', NULL, 0, NULL, NULL, '0000-00-00', 1, 46, 'фыв фыв фывфы ыф', '2018-11-30 10:25:42'),
(14, 1, 'Проект понедельника', 8, 2, 8, '2016-03-21', '0000-00-00', NULL, 0, NULL, NULL, '0000-00-00', 1, 46, 'фыв фыв фывфы ыф', '2018-11-30 10:25:42'),
(15, 1, 'Поставка оборудования (ПЧ 5,5 кВт)', 22, 1, 6, '2016-03-21', '0000-00-00', NULL, 0, NULL, NULL, '0000-00-00', 1, 49, 'фвфВФЫВФыВФВфыв', '2018-11-30 10:25:42'),
(16, 1, 'Поставка оборудования (Спецификация 1)', 13, 1, 6, '2016-03-21', '0000-00-00', NULL, 0, NULL, NULL, '0000-00-00', 1, 46, 'фыВФывВФЫ', '2018-11-30 10:25:42'),
(17, 1, 'Фыыыыы', 15, 1, 1, '2016-03-21', '0000-00-00', '0000-00-00', 0, '0000-00-00', '0000-00-00', '0000-00-00', 5, 46, 'фыВФывВФЫ', '2018-12-14 06:08:54'),
(18, 1, 'Фыыыыы', 45, 1, 14, '2016-03-21', '0000-00-00', NULL, 0, NULL, NULL, '0000-00-00', 1, 46, 'фыВФывВФЫ', '2018-11-30 10:25:42'),
(19, 1, 'Фыыыыы', 8, 1, 0, '2016-03-21', '0000-00-00', '0000-00-00', 0, '0000-00-00', '0000-00-00', '0000-00-00', 6, 46, 'Уважаемые Партнеры!\r\n\r\n \r\n\r\nПрошу принять участие в опросе по маркетингу. Это займет не более 5 минут.\r\n\r\nНиже ссылка на форму с вопросами.\r\n\r\n \r\n \r\n\r\nС уважением,\r\n\r\nПавел Федотов\r\n\r\nМенеджер по работе с ключевыми клиентами', '2018-12-14 06:44:57'),
(20, 1, 'Фыыыыы', 0, 1, 3, '2016-03-21', '0000-00-00', '0000-00-00', 0, '0000-00-00', '0000-00-00', '0000-00-00', 1, 46, 'фыВФывВФЫ', '2018-12-19 13:29:38'),
(21, 1, 'Фыыыыы', 5, 1, 4, '2016-03-21', '0000-00-00', NULL, 0, NULL, NULL, '0000-00-00', 1, 46, 'фыВФывВФЫ', '2018-11-30 10:25:42'),
(22, 1, 'asdfsdvfdsv', 15, 1, 7, '2016-03-23', '0000-00-00', '0000-00-00', 0, '0000-00-00', '0000-00-00', '0000-00-00', 1, 49, 'ssssssssss', '2018-12-29 08:25:27'),
(23, 1, 'Нормальный проект йцуйцу', 45, 1, 1, '2016-03-23', '2018-12-05', '2018-12-22', 0, '2018-12-10', '2018-12-03', '2018-12-06', 2, 46, 'риитти', '2018-12-14 05:08:58'),
(24, 0, 'asdfsdvfdsv', 13, 1, 13, '2016-03-23', '0000-00-00', NULL, 0, NULL, NULL, '0000-00-00', 1, 49, 'ssssssssss', '2018-11-30 10:25:42'),
(25, 1, 'afdsadfadasds', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00', 1, 49, NULL, '0000-00-00 00:00:00'),
(26, 1, 'aaa', NULL, NULL, 0, '0000-00-00', '0000-00-00', '0000-00-00', 0, '0000-00-00', '0000-00-00', '0000-00-00', 1, 0, '', '0000-00-00 00:00:00'),
(27, 1, 'ssss', 0, 0, 0, '0000-00-00', '0000-00-00', '0000-00-00', 0, '0000-00-00', '0000-00-00', '0000-00-00', 1, 0, '', '0000-00-00 00:00:00'),
(28, 1, 'ffff', 0, 1, 0, '2018-12-05', '0000-00-00', '0000-00-00', 0, '0000-00-00', '0000-00-00', '0000-00-00', 9, 0, '', '2018-12-14 12:58:20'),
(29, 1, 'Новый проект', 21, 1, 1, '2018-12-05', '0000-00-00', '0000-00-00', 0, '0000-00-00', '0000-00-00', '0000-00-00', 1, 46, 'Позвонил человек. Хочет купить товар', '2018-12-05 12:34:47'),
(30, 1, 'фыаыаф', 43, 1, 0, '2018-12-11', '0000-00-00', '0000-00-00', 0, '0000-00-00', '0000-00-00', '0000-00-00', 2, 0, '', '2018-12-11 09:04:41'),
(31, 1, 'Какой-то проект о разном', 43, 1, 11, '2018-12-11', '2018-12-04', '2018-12-29', 0, '2018-12-05', '2018-12-08', '2018-12-09', 3, 49, 'Комментарий&quot;вфаы&quot;', '2018-12-20 13:27:48'),
(32, 1, 'фывфы', 0, 1, 9, '2018-12-11', '0000-00-00', '0000-00-00', 0, '0000-00-00', '0000-00-00', '0000-00-00', 4, 0, '&gt;\r\n--&gt;\r\n&lt;/body&gt;', '2018-12-13 10:56:21'),
(33, 1, 'вапвапр', 8, 1, 0, '2018-12-11', '0000-00-00', '0000-00-00', 0, '0000-00-00', '0000-00-00', '0000-00-00', 1, 0, '', '2018-12-11 13:27:46'),
(34, 1, 'Новый проект', 0, 1, 2, '2018-12-11', '0000-00-00', '0000-00-00', 0, '0000-00-00', '0000-00-00', '0000-00-00', 7, 0, '', '2018-12-18 07:08:11'),
(35, 1, 'нннн', 6, 1, 0, '2018-12-12', '0000-00-00', '0000-00-00', 0, '0000-00-00', '0000-00-00', '0000-00-00', 1, 0, '', '2018-12-12 07:14:33'),
(36, 1, 'asaaaaa', 0, 1, 0, '2018-12-13', '0000-00-00', '0000-00-00', 0, '0000-00-00', '0000-00-00', '0000-00-00', 1, 0, '', '2018-12-13 12:44:23'),
(37, 1, 'йцуйцу12313у', 15, 1, 9, '2018-12-14', '0000-00-00', '0000-00-00', 0, '0000-00-00', '0000-00-00', '0000-00-00', 1, 0, 'фывфывКомментарий', '2018-12-14 05:18:23'),
(38, 1, 'ффф', 45, 1, 3, '2018-12-14', '2018-12-07', '2018-12-05', 0, '2018-11-26', '2018-12-01', '2018-12-11', 2, 49, 'Комментарий.', '2018-12-14 12:57:29'),
(39, 1, 'фыв', 20, 1, 0, '2018-12-14', '0000-00-00', '0000-00-00', 0, '0000-00-00', '0000-00-00', '0000-00-00', 9, 0, '', '2018-12-14 05:36:29'),
(40, 1, 'варварв', 0, 1, 0, '2018-12-18', '0000-00-00', '0000-00-00', 0, '0000-00-00', '0000-00-00', '0000-00-00', 9, 0, '', '2018-12-18 11:28:52'),
(41, 1, 'рррр', 0, 1, 0, '2018-12-18', '0000-00-00', '0000-00-00', 0, '0000-00-00', '0000-00-00', '0000-00-00', 9, 0, '', '2018-12-18 11:29:27'),
(42, 1, 'вапавп', 0, 1, 0, '2018-12-18', '0000-00-00', '0000-00-00', 0, '0000-00-00', '0000-00-00', '0000-00-00', 9, 0, '', '2018-12-18 11:29:37'),
(43, 1, 'ааыпавп', 29, 1, 0, '2018-12-18', '0000-00-00', '0000-00-00', 0, '0000-00-00', '0000-00-00', '0000-00-00', 1, 0, '', '2018-12-18 11:01:33'),
(44, 1, 'ооовав', 0, 1, 0, '2018-12-18', '0000-00-00', '0000-00-00', 0, '0000-00-00', '0000-00-00', '0000-00-00', 9, 0, '', '2018-12-18 11:28:58'),
(45, 1, 'рпрпар', 0, 1, 0, '2018-12-18', '0000-00-00', '0000-00-00', 0, '0000-00-00', '0000-00-00', '0000-00-00', 9, 0, '', '2018-12-18 11:29:05'),
(46, 1, 'рвра', 20, 1, 0, '2018-12-18', '0000-00-00', '0000-00-00', 0, '0000-00-00', '0000-00-00', '0000-00-00', 1, 0, '', '2018-12-18 11:03:03'),
(47, 1, 'ппппр', 0, 1, 0, '2018-12-18', '0000-00-00', '0000-00-00', 0, '0000-00-00', '0000-00-00', '0000-00-00', 1, 0, '', '2018-12-18 11:48:50'),
(48, 1, 'прпар', 0, 1, 0, '2018-12-18', '0000-00-00', '0000-00-00', 0, '0000-00-00', '0000-00-00', '0000-00-00', 1, 0, '', '2018-12-18 11:49:24'),
(49, 1, 'прр', 0, 1, 0, '2018-12-18', '0000-00-00', '0000-00-00', 0, '0000-00-00', '0000-00-00', '0000-00-00', 1, 0, '', '2018-12-18 11:49:42'),
(50, 1, 'оооо', 0, 1, 0, '2018-12-18', '0000-00-00', '0000-00-00', 0, '0000-00-00', '0000-00-00', '0000-00-00', 1, 0, '', '2018-12-18 11:50:06'),
(51, 1, 'ыпывпып', 0, 1, 0, '2018-12-18', '0000-00-00', '0000-00-00', 0, '0000-00-00', '0000-00-00', '0000-00-00', 1, 0, '', '2018-12-18 11:50:57'),
(52, 1, 'вапвап', 0, 1, 0, '2018-12-18', '0000-00-00', '0000-00-00', 0, '0000-00-00', '0000-00-00', '0000-00-00', 1, 0, '', '2018-12-20 07:37:05'),
(53, 1, 'апа', 4, 1, 1, '2018-12-18', '0000-00-00', '0000-00-00', 0, '0000-00-00', '0000-00-00', '0000-00-00', 4, 49, '', '2018-12-25 09:37:55'),
(54, 1, 'вапавп', 17, 1, 0, '2018-12-20', '0000-00-00', '0000-00-00', 0, '0000-00-00', '0000-00-00', '0000-00-00', 1, 0, '', '2018-12-20 07:32:05'),
(55, 1, 'Поставка ПЧ', 1, 1, 2, '2018-12-26', '2018-12-30', '0000-00-00', 0, '0000-00-00', '0000-00-00', '0000-00-00', 2, 49, 'Заказчик хочет что-то такое необычное. Лучше, чем у других. &quot;ккк&quot;вавыа', '2019-01-15 07:41:43'),
(56, 1, 'Ремонт ПЧ', 4, 1, 11, '2018-12-29', '0000-00-00', '0000-00-00', 0, '0000-00-00', '0000-00-00', '0000-00-00', 2, 46, 'тел...', '2018-12-29 08:33:34'),
(57, 1, 'Поставка вентиляторов', 0, 1, 0, '2019-01-09', '0000-00-00', '0000-00-00', 0, '0000-00-00', '0000-00-00', '0000-00-00', 1, 0, 'Юр. адрес:\r\n&quot;фыв&quot;\r\n Республика Казахстан, 160050,\r\n\r\nг. Шымкент,  17 мкр, д. 11А, кв 21\r\n\r\nФакт.адрес: Республика Казахстан\r\n\r\nг. Шымкент, Тамерлановское шоссе, бн\r\n\r\nБизнес-Центр «МАРС», офис 32\r\n\r\nИНН 582100258074\r\n\r\nБИН 060340018192\r\n\r\nИИК KZ85914122203KZ000KS\r\n\r\nФилиал ДБ АО «Сбербанк» в г. Шымкент\r\n\r\nSWIFT: SABRKZKA\r\n\r\n \r\n\r\n \r\n\r\nДобрый день!\r\n\r\n \r\n\r\nПросим Вас, выслать в наш адрес предложение  на поставку следующего товара:\r\n\r\n\r\nВентилятор охлаждения/ для частотного преобразователя. В связи с унификацией и дооснащением. Запчасть от\r\nчастотных преобразователей Danfoss VLT FC- 102N250T4.\r\n\r\n \r\n\r\nВ количестве 3 штук.\r\n\r\nПри отсутствии прошу предложить аналоги.\r\n\r\nЕсть партнеры на территории РФ.\r\n\r\nНа условия 100% предоплаты и самовывоза\r\n\r\n \r\n\r\nЕсли Вас не затруднит, просим  указать полное наименование, технические характеристики(включая год выпуска), наличие сертификатов,  также наличие товара и  сроки поставки.\r\n\r\n \r\n\r\nОтдельно просим Вас указать габариты упаковки для транспортировки груза\r\n\r\n.\r\n\r\nВ случае, если Вы, по каким-то причинам, не сможете направить нам предложение, просим сообщить об этом в минимальный срок.\r\n\r\n \r\n\r\n \r\n\r\n\r\n\r\nПрошу сохранять историю переписки! \r\n\r\nС уважением, \r\nРжевская Анна Сергеевна,   менеджер отдела закупок\r\nТОО &quot;АЗИЯ ПРОМТЭКС&quot;, г. Шымкент, Республика Казахстан.\r\nтел: +7 778 933 1329 \r\nтел: +7 (7252) 270020', '2019-01-15 04:51:57'),
(58, 0, 'аапи &quot;ыввыа&quot; ыва ыва', 0, 1, 0, '2019-01-15', '0000-00-00', '0000-00-00', 0, '0000-00-00', '0000-00-00', '0000-00-00', 1, 0, '', '2019-01-15 06:50:26'),
(59, 1, 'Поставка компрессора', 54, 1, 1, '2019-01-15', '0000-00-00', '0000-00-00', 0, '0000-00-00', '0000-00-00', '0000-00-00', 2, 49, 'в продолжение нашего разговора отправляю Вам\r\nпараметры частотного преобразователя марки Lenze, его\r\nаналог нам и необходим, просьба подсказать\r\nсроки поставки', '2019-01-15 11:23:02'),
(60, 1, 'Поставка товара 4 кВт', 55, 1, 3, '2019-01-17', '0000-00-00', '0000-00-00', 0, '0000-00-00', '0000-00-00', '0000-00-00', 2, 49, ' 4 кВт', '2019-01-18 05:23:36'),
(61, 1, 'Поставка ПЧ Дельта', 56, 1, 1, '2019-01-23', '0000-00-00', '0000-00-00', 0, '0000-00-00', '0000-00-00', '0000-00-00', 2, 49, '', '2019-01-23 04:44:38');

-- --------------------------------------------------------

--
-- Структура таблицы `project_status`
--

CREATE TABLE `project_status` (
  `id` int(11) NOT NULL,
  `sort` int(11) NOT NULL,
  `active` int(1) NOT NULL,
  `value` varchar(64) NOT NULL,
  `name` varchar(64) NOT NULL,
  `background_color` varchar(10) NOT NULL,
  `color` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `project_status`
--

INSERT INTO `project_status` (`id`, `sort`, `active`, `value`, `name`, `background_color`, `color`) VALUES
(1, 10, 1, 'На регистрации', 'onreg', '#FF00FF', '#fff'),
(2, 20, 1, 'Подготовка', 'training', '#ff6', '#000'),
(3, 30, 1, 'Напомнить', 'remind', '#00FF66', '#f00'),
(4, 40, 1, 'В работе', 'go', '#00FF66', '#000'),
(5, 50, 1, 'Сопровождение', 'escort', '#336699', '#fff'),
(6, 60, 1, 'Где деньги?', 'money', '#6699FF', '#fff'),
(7, 70, 1, 'Где акт?', 'act', '#6699FF', '#fff'),
(8, 80, 1, 'Выполнено', 'ok', '#ddd', '#999'),
(9, 90, 1, 'Отменено', 'cancel', '#FF99CC', '#f00');

-- --------------------------------------------------------

--
-- Структура таблицы `project_type`
--

CREATE TABLE `project_type` (
  `id` int(11) NOT NULL,
  `sort` int(11) NOT NULL,
  `active` int(1) NOT NULL,
  `value` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `reports`
--

CREATE TABLE `reports` (
  `id` int(11) NOT NULL,
  `datetime` timestamp NOT NULL,
  `author` int(11) NOT NULL,
  `page` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `result` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `reports`
--

INSERT INTO `reports` (`id`, `datetime`, `author`, `page`, `message`, `result`) VALUES
(1, '2018-12-26 06:28:47', 1, '', 'safa', 0),
(2, '2018-12-26 06:29:10', 1, '', 'safa', 0),
(3, '2018-12-26 06:29:14', 1, '', 'adfdsf', 0),
(4, '2018-12-26 06:31:45', 1, '', 'asdfsdfgsdfg', 0),
(5, '2018-12-26 06:33:14', 1, '', 'dasfdsf', 0),
(6, '2018-12-26 06:34:46', 1, '', 'dasfdsf', 0),
(7, '2018-12-26 06:34:50', 1, 'http://192.168.1.111/index.php?cat=report', 'asfdaf', 0),
(8, '2018-12-26 06:35:08', 1, 'http://192.168.1.111/index.php?cat=prj&amp;op=main&amp;select=archive', 'afdfsf', 0),
(9, '2018-12-26 06:36:04', 1, 'http://192.168.1.111/index.php?cat=prj&amp;op=main&amp;select=archive', 'sgdfgdsfg', 0),
(10, '2018-12-26 06:36:51', 1, 'http://192.168.1.111/index.php?cat=prj&amp;op=main&amp;select=archive', 'Warning: mysql_result(): Unable to jump to row 0 on MySQL result index 41 in W:domainslocalhostprojectsmain.php on line 70', 0),
(11, '2018-12-26 06:38:14', 1, 'http://192.168.1.111/index.php?cat=prj&amp;op=main&amp;select=archive', 'fgjh', 0),
(12, '2018-12-26 06:38:54', 1, 'http://192.168.1.111/index.php?cat=prj&amp;op=main&amp;select=archive', 'Warning: mysql_result(): Unable to jump to row 0 on MySQL result index 41 in W:domainslocalhostprojectsmain.php on line 70', 0),
(13, '2018-12-26 07:53:45', 1, '', 'style=&quot;color:#f00;&quot;', 0),
(14, '2018-12-26 07:54:14', 1, '', 'fghfgh', 0),
(15, '2018-12-26 07:54:43', 1, '', 'fghdghf', 0),
(16, '2018-12-26 08:51:53', 1, '', 'asdasd', 0),
(17, '2018-12-26 08:52:29', 1, '', 'asdasd', 0),
(18, '2018-12-26 08:52:35', 1, 'http://192.168.1.111/index.php?cat=report_list', 'asdsa', 0),
(19, '2018-12-26 09:13:26', 1, 'http://192.168.1.111/index.php?cat=rep&amp;op=newreport', 'asasd', 0),
(20, '2018-12-26 09:14:35', 1, 'http://192.168.1.111/index.php?cat=usr&amp;op=show&amp;id=1', 'bmbm', 0),
(21, '2018-12-26 09:25:12', 1, 'http://192.168.1.111/index.php?cat=rep', 'jhkk', 0),
(22, '2018-12-26 09:26:03', 1, 'http://192.168.1.111/index.php?cat=rep&amp;op=confirm&amp;id=21', 'asdsad', 0),
(23, '2018-12-26 09:26:17', 1, 'http://192.168.1.111/index.php?cat=frm&amp;op=main', 'fdbdfb', 0),
(24, '2018-12-26 09:26:21', 1, 'http://192.168.1.111/index.php?cat=prj&amp;op=main', 'bfdbxfgbf', 0),
(25, '2018-12-26 09:26:25', 1, 'http://192.168.1.111/index.php?cat=rep&amp;op=newreport', 'gbbfxb', 0),
(26, '2018-12-26 09:54:24', 1, 'http://192.168.1.111/index.php?cat=rep&amp;op=main&amp;select=all', 'asfaf', 0),
(27, '2018-12-26 09:55:12', 3, 'http://192.168.1.111/index.php', 'nmbnm', 0),
(28, '2018-12-26 09:55:37', 3, 'http://192.168.1.111/index.php?cat=frm&amp;op=main', 'asfafsdaf', 0),
(29, '2018-12-26 09:58:06', 3, 'http://192.168.1.111/index.php?cat=prj&amp;op=main', 'http://192.168.1.111/images/ops.png', 0),
(30, '2018-12-26 10:08:13', 1, 'http://192.168.1.111/index.php?cat=rep&amp;op=main&amp;select=all', 'http://192.168.1.111/images/ops.png', 0),
(31, '2018-12-26 10:21:10', 1, 'http://192.168.1.111/index.php?cat=rep&amp;op=newreport', 'выаыа', 0),
(32, '2018-12-26 11:57:53', 1, 'http://192.168.1.111/index.php?cat=prj&amp;op=edit&amp;id=55', 'Warning: mysql_result(): Unable to jump to row 0 on MySQL result index 43 in W:domainslocalhostprojectsprj_edit.php on line 63', 0),
(33, '2018-12-26 12:05:46', 1, 'http://192.168.1.111/index.php?cat=prj&amp;op=main&amp;select=archive', 'Warning: mysql_result(): Unable to jump to row 0 on MySQL result index 42 in W:domainslocalhostprojectsmain.php on line 70', 0),
(34, '2018-12-26 12:47:11', 1, 'http://192.168.1.111/index.php?cat=rep', 'вваав', 0),
(35, '2018-12-26 12:47:13', 1, 'http://192.168.1.111/index.php?cat=rep', 'вваав', 0),
(36, '2018-12-26 12:47:30', 1, 'http://192.168.1.111/index.php?cat=rep', 'еккерке', 0),
(37, '2018-12-26 12:47:39', 1, 'http://192.168.1.111/index.php?cat=rep', 'куепукп', 0),
(38, '2018-12-26 12:48:01', 1, 'http://192.168.1.111/index.php?cat=rep', 'апрапр', 0),
(39, '2018-12-26 12:48:10', 1, 'http://192.168.1.111/index.php?cat=rep', 'http://192.168.1.111/images/ops.png', 0),
(40, '2018-12-26 12:51:05', 1, 'http://192.168.1.111/index.php?cat=rep&amp;op=main&amp;select=all', 'http://192.168.1.111/images/ops.png', 0),
(41, '2018-12-26 12:52:16', 1, 'http://192.168.1.111/index.php?cat=rep', 'ппрп', 0),
(42, '2018-12-26 12:55:02', 1, 'http://192.168.1.111/index.php?cat=usr&amp;op=show&amp;id=1', 'http://192.168.1.111/images/ops.png', 0),
(43, '2018-12-26 13:11:25', 1, 'http://192.168.1.111/index.php?cat=usr&amp;op=show&amp;id=1', 'Создание нового контакта', 0),
(44, '2018-12-26 13:11:38', 1, 'http://192.168.1.111/index.php?cat=rep&amp;op=newreport', 'Редактирование данных контакта', 0),
(45, '2018-12-26 13:12:28', 1, 'http://192.168.1.111/index.php?cat=prj&amp;op=show&amp;id=55', 'В проекты добавить блок &quot;контакты&quot;', 0),
(46, '2018-12-26 13:13:45', 1, 'http://192.168.1.111/index.php?cat=usr&amp;op=show&amp;id=28', 'Сделать прикрепление юзеров к проектам.', 0),
(47, '2018-12-28 10:15:41', 1, 'http://192.168.1.111/index.php?cat=usr&amp;op=edit&amp;id=1', 'Добавление пользователя', 0),
(48, '2018-12-28 10:15:50', 1, 'http://192.168.1.111/index.php?cat=rep&amp;op=newreport', 'Редактирование пользователя', 0),
(49, '2018-12-28 11:56:26', 3, 'http://192.168.1.111/index.php?cat=usr&amp;op=main&amp;select=my', 'fjhhgjghj', 0),
(50, '2018-12-28 11:57:50', 3, 'http://192.168.1.111/index.php?cat=usr&amp;op=main&amp;select=my', 'as', 0),
(51, '2018-12-28 11:57:53', 3, 'http://192.168.1.111/index.php?cat=usr&amp;op=main&amp;select=my', 'as', 0),
(52, '2018-12-28 11:57:55', 3, 'http://192.168.1.111/index.php?cat=usr&amp;op=main&amp;select=my', 'as', 0),
(53, '2018-12-28 11:58:28', 3, 'http://192.168.1.111/index.php?cat=usr&amp;op=main&amp;select=my', 'as', 0),
(54, '2018-12-28 11:58:49', 3, 'http://192.168.1.111/index.php?cat=usr&amp;op=main&amp;select=my', 'as', 0),
(55, '2018-12-28 11:59:19', 3, 'http://192.168.1.111/index.php?cat=usr&amp;op=main&amp;select=my', 'as', 0),
(56, '2018-12-28 11:59:30', 3, 'http://192.168.1.111/index.php?cat=usr&amp;op=main&amp;select=my', 'as', 0),
(57, '2018-12-28 12:07:13', 3, 'http://192.168.1.111/index.php', 'test', 0),
(58, '2018-12-29 05:00:57', 1, 'http://192.168.1.111/index.php?cat=frm&amp;op=main&amp;sort=desc', 'Поместить фирму в черный лист', 1),
(59, '2018-12-29 05:01:13', 1, 'http://192.168.1.111/index.php?cat=rep&amp;op=newreport', 'Удалить фирму из черного листа\r\n', 1),
(60, '2018-12-29 08:07:40', 1, 'http://192.168.1.111/index.php?cat=usr&amp;op=usr_edit_prj&amp;id=55&amp;user=28', 'Warning: mysql_result(): Unable to jump to row 0 on MySQL result index 45 in W:domainslocalhostusersusr_edit_prj.php on line 35', 0),
(61, '2018-12-29 08:08:16', 1, 'http://192.168.1.111/index.php?cat=usr&amp;op=usr_edit_prj&amp;id=55&amp;user=28', 'Warning: mysql_result(): Unable to jump to row 0 on MySQL result index 45 in W:domainslocalhostusersusr_edit_prj.php on line 35', 0),
(62, '2018-12-29 08:08:47', 1, 'http://192.168.1.111/index.php?cat=usr&amp;op=usr_edit_prj&amp;id=55&amp;user=28', 'Warning: mysql_result(): Unable to jump to row 0 on MySQL result index 45 in W:domainslocalhostusersusr_edit_prj.php on line 35', 0),
(63, '2018-12-29 08:08:49', 1, 'http://192.168.1.111/index.php?cat=usr&amp;op=usr_edit_prj&amp;id=55&amp;user=28', 'Warning: mysql_result(): Unable to jump to row 0 on MySQL result index 45 in W:domainslocalhostusersusr_edit_prj.php on line 35', 0),
(64, '2018-12-29 08:08:50', 1, 'http://192.168.1.111/index.php?cat=usr&amp;op=usr_edit_prj&amp;id=55&amp;user=28', 'Warning: mysql_result(): Unable to jump to row 0 on MySQL result index 45 in W:domainslocalhostusersusr_edit_prj.php on line 35', 0),
(65, '2018-12-29 08:08:53', 1, 'http://192.168.1.111/index.php?cat=usr&amp;op=usr_edit_prj&amp;id=55&amp;user=28', 'Warning: mysql_result(): Unable to jump to row 0 on MySQL result index 45 in W:domainslocalhostusersusr_edit_prj.php on line 35', 0),
(66, '2018-12-29 08:09:39', 1, 'http://192.168.1.111/index.php?cat=rep', '1', 0),
(67, '2018-12-29 08:09:46', 1, 'http://192.168.1.111/index.php?cat=rep', 'http://192.168.1.111/index.php?cat=rep', 0),
(68, '2018-12-29 08:10:34', 1, 'http://192.168.1.111/index.php?cat=rep', 'Добавление фирмы', 0),
(69, '2018-12-29 08:10:40', 1, 'http://192.168.1.111/index.php?cat=rep&amp;op=newreport', 'Редактирование фирмы', 0),
(70, '2018-12-29 08:19:41', 1, 'http://192.168.1.111/index.php?cat=rep', 'Множественная вставка (6 копий)', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `tasks`
--

CREATE TABLE `tasks` (
  `task_id` int(11) NOT NULL,
  `task_active` int(11) NOT NULL DEFAULT '1',
  `task_author` int(11) DEFAULT NULL,
  `task_lid` int(11) DEFAULT NULL,
  `task_datetime_reg` timestamp NULL DEFAULT NULL COMMENT 'время создания задачи',
  `task_name` text COMMENT 'название задачи',
  `task_text` text CHARACTER SET utf8mb4 COMMENT 'текст задачи',
  `task_datetime_limit` timestamp NULL DEFAULT NULL COMMENT 'срок выполнения',
  `task_finish_flag` int(11) DEFAULT '0' COMMENT 'флаг выполнения задачи',
  `task_datetime_finish` timestamp NULL DEFAULT NULL COMMENT 'время выполнения задачи',
  `task_result` text COMMENT 'текст результата',
  `task_firm` int(11) DEFAULT NULL COMMENT 'задача для фирмы',
  `task_project` int(11) DEFAULT NULL COMMENT 'задача для проекта',
  `task_user_finish` int(11) DEFAULT NULL COMMENT 'кто завершил задачу'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `uid` int(11) NOT NULL,
  `username` varchar(64) DEFAULT NULL,
  `user_psevdonim` varchar(64) NOT NULL,
  `password` varchar(64) DEFAULT NULL,
  `sid` varchar(64) DEFAULT NULL,
  `user_active` tinyint(1) DEFAULT '1',
  `user_email` text,
  `user_role` int(4) DEFAULT NULL,
  `user_date_add` date DEFAULT NULL,
  `user_mobtelno` text,
  `user_comment` text,
  `user_lastvisit` datetime DEFAULT NULL,
  `user_dob` date NOT NULL COMMENT 'День рождения',
  `edit_author` int(11) NOT NULL,
  `edit_datetime` timestamp NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`uid`, `username`, `user_psevdonim`, `password`, `sid`, `user_active`, `user_email`, `user_role`, `user_date_add`, `user_mobtelno`, `user_comment`, `user_lastvisit`, `user_dob`, `edit_author`, `edit_datetime`) VALUES
(1, 'admin', '', '6512bd43d9caa6e02c990b0a82652dca', 'les9pmaa74ped5vhpasto6rdm0', 1, 'admin@google.com', 100, '2016-03-01', '+7-960-635-01-01', 'Комментарий\r\n&quot;фыв&quot;', NULL, '1985-01-01', 1, '2019-01-15 04:51:25'),
(2, 'Константинопольский Константин Константинович', '', 'c4ca4238a0b923820dcc509a6f75849b', 'les9pmaa74ped5vhpasto6rdm0', 1, 'mail2@mail.ru', 3, NULL, '+7-960-123-45-67_ред', '', NULL, '0000-00-00', 1, '2019-01-15 05:37:01'),
(3, 'user', '', 'c4ca4238a0b923820dcc509a6f75849b', 'kdt3iflbo9u05iqg4mnho5r8o3', 1, 'qweqwe@mail.ru', 3, NULL, '+7-960-123-45-67', '', NULL, '0000-00-00', 0, '0000-00-00 00:00:00'),
(4, 'Иванов Иван Иванович1', '', 'Иванов Иван Иванович2', NULL, 1, 'Иванов Иван Иванович3', 3, '2016-03-14', '+7-960-123-45-67', '', NULL, '0000-00-00', 0, '0000-00-00 00:00:00'),
(5, 'Иванов1', '', '1', NULL, 1, 'Иванов3', 3, '2016-03-14', '+7-960-123-45-67', '', NULL, '0000-00-00', 0, '0000-00-00 00:00:00'),
(6, 'Иванов1', '', 'c4ca4238a0b923820dcc509a6f75849b', NULL, 1, 'Иванов3', 3, '2016-03-14', '+7-960-123-45-67', 'Иванов15', NULL, '0000-00-00', 0, '0000-00-00 00:00:00'),
(7, 'Иванов Иван Иванович123', '', 'c4ca4238a0b923820dcc509a6f75849b', NULL, 1, 'e-mail', 3, '2016-03-14', '+79123456789', '', NULL, '0000-00-00', 0, '0000-00-00 00:00:00'),
(8, 'фыаыфвафыва', '', 'c4ca4238a0b923820dcc509a6f75849b', NULL, 1, '', 3, '2014-03-16', '+7-960-123-45-67', '', NULL, '0000-00-00', 0, '0000-00-00 00:00:00'),
(9, 'Сидоров Сидор Петрович', '', 'c4ca4238a0b923820dcc509a6f75849b', '4uk8o0n420fr0cnvndrvpvmvh4', 1, 'фыв', 3, '2016-03-14', '+7-960-123-45-67', '', NULL, '0000-00-00', 0, '0000-00-00 00:00:00'),
(10, 'Путин Владимир Владимирович', '', 'a1320ae11a20e14397970b4ac1b39e71', NULL, 1, 'mail@mail.ru', 3, '2016-03-15', '112', 'Кремль...', NULL, '0000-00-00', 0, '0000-00-00 00:00:00'),
(11, 'Зайцев Федор Петрович', '', 'c4ca4238a0b923820dcc509a6f75849b', NULL, 1, '1@m.ru', 3, '2016-03-15', '', '', NULL, '0000-00-00', 0, '0000-00-00 00:00:00'),
(12, 'фыввыфв1211', '', '1', NULL, 1, '', 3, '2016-03-29', '', '', NULL, '0000-00-00', 0, '0000-00-00 00:00:00'),
(13, 'фыввыфв1211', '', '1', NULL, 1, '', 3, '2016-03-29', '', '', NULL, '0000-00-00', 0, '0000-00-00 00:00:00'),
(14, 'ФФФФФФ123', '', '1', NULL, 1, '', 3, '2016-03-29', '', '', NULL, '0000-00-00', 0, '0000-00-00 00:00:00'),
(15, 'Цццццццццй 4', '', '1', NULL, 1, '', 3, '2016-03-30', '', '', NULL, '0000-00-00', 0, '0000-00-00 00:00:00'),
(16, 'гомункул', '', '1', NULL, 1, '', 3, '2016-04-05', '', '', NULL, '0000-00-00', 0, '0000-00-00 00:00:00'),
(17, 'Зайцев Николай Иванович', '', '1', NULL, 1, 'zaycev@prioskolie.ru', 3, '2017-03-23', '8-980-377-15-18', '', NULL, '0000-00-00', 0, '0000-00-00 00:00:00'),
(18, 'Костылев Евгений Михайлович', '', '1', NULL, 1, '', 3, '2017-03-23', '8-919-289-94-93', '', NULL, '0000-00-00', 0, '0000-00-00 00:00:00'),
(19, 'Меллюханов Игорь Васильевич', '', '1', NULL, 1, 'MIV@prioskolie.ru', 3, '2017-03-23', '8-910-361-86-82', '', NULL, '0000-00-00', 0, '0000-00-00 00:00:00'),
(20, 'Термус Сергей ', '', '1', NULL, 1, '79194373752@ya.ru', 3, '2017-03-23', '8-919-437-37-52', '', NULL, '0000-00-00', 0, '0000-00-00 00:00:00'),
(21, 'Клименко Виталий', '', '1', NULL, 1, 'klimenko_val@prioskolie.ru', 3, '2017-03-23', '8-920-564-01-35', '', NULL, '0000-00-00', 0, '0000-00-00 00:00:00'),
(22, 'Кувшинов Геннадий', '', '1', NULL, 1, 'gfk-11@yandex.ru', 3, '2017-03-23', '', '', NULL, '0000-00-00', 0, '0000-00-00 00:00:00'),
(23, 'Леденёв Павел', '', '1', NULL, 1, 'ledenev@prioskolie.ru', 3, '2017-03-23', '8-980-324-96-82', '', NULL, '0000-00-00', 0, '0000-00-00 00:00:00'),
(24, 'Брагин Андрей Леонидович', '', '1', NULL, 1, '456st-bragin@mail.ru', 3, '2017-03-23', '123', '789 &quot;000&quot; 12341', NULL, '1980-12-01', 1, '2018-12-28 11:04:48'),
(25, 'йцу', '', '1', NULL, 1, '', 3, '2017-03-23', '', '', NULL, '0000-00-00', 0, '0000-00-00 00:00:00'),
(26, 'фывфавйцу', '', '1', NULL, 1, '', 3, '2017-03-23', '', '', NULL, '0000-00-00', 0, '0000-00-00 00:00:00'),
(27, 'qwerty', '', '1', NULL, 1, '', 3, '2017-03-23', '', '', NULL, '0000-00-00', 0, '0000-00-00 00:00:00'),
(28, 'Колодин Константин Бусильдович', '', '1', NULL, 1, 'longemailadresverylongmorelongest@mail.ru', 3, '2017-03-23', '+7-910-100-12-34', 'Хороший контакт.\r\nИ вообще.', NULL, '1970-01-01', 1, '2019-01-15 05:30:38'),
(29, 'zcxzcxzczc', '', '1', NULL, 1, '', 3, '2017-03-23', '', '', NULL, '0000-00-00', 0, '0000-00-00 00:00:00'),
(30, 'фывыффы', '', '1', NULL, 1, '', 3, '2017-03-24', '', '', NULL, '0000-00-00', 0, '0000-00-00 00:00:00'),
(31, 'иписи', '', '1', NULL, 1, '', 3, '2017-03-24', '', '', NULL, '0000-00-00', 0, '0000-00-00 00:00:00'),
(32, 'йййй', '', '1', NULL, 1, '', 3, '2017-03-24', '', '', NULL, '0000-00-00', 0, '0000-00-00 00:00:00'),
(33, 'фыфффф', '', '1', NULL, 1, '', 3, '2017-03-24', '', '', NULL, '0000-00-00', 0, '0000-00-00 00:00:00'),
(34, 'ккк', '', '1', NULL, 1, '', 3, '2017-03-24', '', '', NULL, '0000-00-00', 0, '0000-00-00 00:00:00'),
(35, 'zzzz', '', '1', NULL, 0, '', 3, '2017-03-24', '', '', NULL, '0000-00-00', 1, '2018-12-28 10:36:46'),
(36, 'Никнэйм', '', '1', NULL, 1, '222', 3, '2018-12-28', '111', '333&quot;44&quot;555', NULL, '1970-12-19', 1, '0000-00-00 00:00:00'),
(37, 'апрапрап', '', '1', NULL, 1, '5н5укнрк5ннф4 ф  н4ц ы5ыв5', 3, '2018-12-28', 'екн54н', '3244к534 н н5ы 5н нв5 5к к', NULL, '1980-11-27', 1, '2018-12-28 11:21:35'),
(38, 'Максим', '', '1', NULL, 1, '43', 3, '2018-12-29', '123', 'уаыу', NULL, '0000-00-00', 1, '0000-00-00 00:00:00'),
(39, 'Череватюк Евгений', '', '1', NULL, 1, 'info@rekom.su', 0, '2019-01-15', '+7-950-715-69-44', '', NULL, '0000-00-00', 1, '0000-00-00 00:00:00'),
(40, 'Низовский Илья', '', '1', NULL, 1, 'silarius@mail.ru', 0, '2019-01-17', '', '', NULL, '0000-00-00', 1, '0000-00-00 00:00:00'),
(47, '1', '', '1', NULL, 0, '', 0, '2019-01-18', '', '', NULL, '0000-00-00', 1, '0000-00-00 00:00:00'),
(48, '1', '', '1', NULL, 0, '', 0, '2019-01-18', '', '', NULL, '0000-00-00', 1, '0000-00-00 00:00:00'),
(49, '1', '', '1', NULL, 0, '', 0, '2019-01-18', '', '', NULL, '0000-00-00', 1, '0000-00-00 00:00:00'),
(50, '1', '', '1', NULL, 0, '', 0, '2019-01-18', '', '', NULL, '0000-00-00', 1, '0000-00-00 00:00:00'),
(51, '1', '', '1', NULL, 0, '', 0, '2019-01-18', '', '', NULL, '0000-00-00', 1, '0000-00-00 00:00:00'),
(52, '1', '', '1', NULL, 0, '', 0, '2019-01-18', '', '', NULL, '0000-00-00', 1, '0000-00-00 00:00:00'),
(53, '1', '', '1', NULL, 0, '', 0, '2019-01-18', '', '', NULL, '0000-00-00', 1, '0000-00-00 00:00:00'),
(54, '1', '', '1', NULL, 0, '', 0, '2019-01-18', '', '', NULL, '0000-00-00', 1, '0000-00-00 00:00:00'),
(55, '1', '', '1', NULL, 0, '', 0, '2019-01-18', '', '', NULL, '0000-00-00', 1, '0000-00-00 00:00:00'),
(56, '1', '', '1', NULL, 0, '', 0, '2019-01-18', '', '', NULL, '0000-00-00', 1, '0000-00-00 00:00:00'),
(57, 'Зайковский Владимир Витальевич', '', '1', NULL, 1, '', 0, '2019-01-18', '+7-910-229-01-78', '', NULL, '0000-00-00', 1, '0000-00-00 00:00:00'),
(100, 'Бондаренко Валерий Валериевич', '', '1', NULL, 1, '', 0, '2019-01-18', '+7-960-640-48-58', '', NULL, '0000-00-00', 3, '2019-01-18 10:41:32'),
(101, 'Мурмыло Владимир', '', '1', NULL, 1, 'mur_vladimir@mail.ru', 0, '2019-01-18', '+7-910-229-14-84', '', NULL, '0000-00-00', 1, '2019-01-18 06:03:22'),
(102, 'Гладун Сергей', '', '1', NULL, 1, '', 0, '2019-01-18', '+7-910-221-75-34', '', NULL, '0000-00-00', 1, '0000-00-00 00:00:00'),
(103, 'Крыжановский Александр Владимирович', '', '1', NULL, 1, '', 0, '2019-01-18', '+7-910-329-54-05', '', NULL, '0000-00-00', 1, '0000-00-00 00:00:00'),
(104, 'Киданов Валерий ', '', '1', NULL, 1, '', 0, '2019-01-18', '', '', NULL, '0000-00-00', 1, '0000-00-00 00:00:00'),
(105, 'Высоцкий Денис Николаевич', '', '1', NULL, 1, '', 0, '2019-01-18', '+7-910-225-20-81', '', NULL, '0000-00-00', 1, '0000-00-00 00:00:00'),
(106, 'Давыденко Константин', '', '1', NULL, 1, '47a@mail.ru', 0, '2019-01-23', '', '', NULL, '0000-00-00', 1, '2019-01-23 04:42:52');

-- --------------------------------------------------------

--
-- Структура таблицы `user_to_firm`
--

CREATE TABLE `user_to_firm` (
  `id` int(11) NOT NULL,
  `active` int(1) NOT NULL DEFAULT '1',
  `user_id` int(11) NOT NULL,
  `firm_id` int(11) NOT NULL,
  `tel` varchar(64) NOT NULL,
  `email` text NOT NULL,
  `comment` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `user_to_firm`
--

INSERT INTO `user_to_firm` (`id`, `active`, `user_id`, `firm_id`, `tel`, `email`, `comment`) VALUES
(1, 1, 1, 46, '8-900-123-45-67', 'e1@mail.ru', 'Комментарий 1'),
(2, 1, 1, 49, '8-900-900-12-34', 'e2@mail.ru', 'Комментарий 2'),
(3, 0, 2, 4, '8-900-900-12-34', '', ''),
(4, 0, 2, 49, '8-900-900-12-34', '', 'xcvxvsdfx'),
(5, 1, 4, 9, '', 'asdad@gfgd.ru', ''),
(6, 1, 6, 8, '', '', 'xcvxcvcxvxc'),
(7, 0, 28, 45, '8-960-630-90-90', 'mail@34.com', 'Комментарий. Комментарий.\"ыфав\"'),
(8, 0, 28, 49, '8-960-630-80-81', 'asd@gufdhg.ru', 'фыафыавыаывпфку п ук пуык пкуып'),
(9, 0, 1, 15, '43к543к5', '435345', 'ывапы'),
(10, 0, 1, 11, '+7-920-201-20-01', 'admin@yandex.ru', 'Крутой специалист'),
(11, 0, 1, 17, '123', '456', '789 &quot;123&quot; 41'),
(12, 0, 1, 45, '', '', ''),
(13, 1, 11, 15, '3453456', '346346е', '346346е3кепап'),
(14, 1, 7, 12, '(4722) 30-00-12', 'asdaskdf@mail.ru', 'энергетик'),
(15, 1, 28, 1, '8-920-200-90-80', 'predpriyatie@predpriyatie.com', 'Директор'),
(16, 1, 28, 11, '8-800-123-45-67', 'fia5@yandex.ru', 'Энергетик'),
(17, 1, 7, 1, '', '', ''),
(18, 1, 39, 54, '+7 (473) 228-60-69', 'info@rekom.su', 'www.rekom.su'),
(19, 1, 40, 55, '(3812)999-527', 'silarius@mail.ru', ''),
(20, 1, 100, 4, '35-41-50', 'bondarenko_vv@energomash.ru', 'Заместитель директора по ЭБ'),
(21, 1, 101, 4, '', '', 'Начальник отдела пром. электроники'),
(22, 1, 102, 4, '', 's_gladun@energomash.ru', 'мастер высоковольтных сетей и подстанций СЭ и Р'),
(23, 1, 103, 4, '', '', 'Гл.менеджер - руководитель ГМТОиР'),
(24, 1, 104, 4, '', 'valery_kidanov@energomash.ru', 'Начальник охраны ЗМК'),
(25, 1, 105, 4, '35-44-58', 'denis_vysotskiy@energomash.ru', 'Ведущий специалист теплотехник\r\n'),
(26, 1, 57, 4, '', 'Vladimir_Zajkovsky@energomash.ru', 'Отдел главного механика'),
(27, 1, 106, 56, '(4722) 21-56-14', '', 'Инженер отдела оборудования');

-- --------------------------------------------------------

--
-- Структура таблицы `user_to_project`
--

CREATE TABLE `user_to_project` (
  `id` int(11) NOT NULL,
  `active` int(1) NOT NULL DEFAULT '1',
  `user_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `role` int(11) NOT NULL,
  `date_add` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `user_to_project`
--

INSERT INTO `user_to_project` (`id`, `active`, `user_id`, `project_id`, `role`, `date_add`) VALUES
(1, 1, 2, 24, 1, '2017-01-07'),
(2, 1, 2, 23, 1, '2018-01-01'),
(3, 0, 3, 22, 1, '2018-12-05'),
(4, 1, 2, 21, 1, '2018-12-03'),
(5, 1, 2, 22, 0, '2018-12-28'),
(6, 0, 2, 4, 0, '2018-12-28'),
(7, 1, 28, 55, 0, '2018-12-28'),
(8, 1, 7, 22, 0, '2018-12-28'),
(9, 0, 38, 4, 0, '2018-12-29'),
(10, 1, 28, 3, 0, '2019-01-15'),
(11, 1, 28, 6, 0, '2019-01-15'),
(12, 1, 7, 6, 0, '2019-01-15'),
(13, 1, 39, 59, 0, '2019-01-15'),
(14, 1, 40, 60, 0, '2019-01-17'),
(15, 1, 106, 61, 0, '2019-01-23');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `firms`
--
ALTER TABLE `firms`
  ADD PRIMARY KEY (`firm_id`);

--
-- Индексы таблицы `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`mess_id`);

--
-- Индексы таблицы `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Индексы таблицы `products_group`
--
ALTER TABLE `products_group`
  ADD PRIMARY KEY (`group_id`);

--
-- Индексы таблицы `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`pr_id`);

--
-- Индексы таблицы `project_status`
--
ALTER TABLE `project_status`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `project_type`
--
ALTER TABLE `project_type`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`task_id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`uid`);

--
-- Индексы таблицы `user_to_firm`
--
ALTER TABLE `user_to_firm`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `user_to_project`
--
ALTER TABLE `user_to_project`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `firms`
--
ALTER TABLE `firms`
  MODIFY `firm_id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT для таблицы `messages`
--
ALTER TABLE `messages`
  MODIFY `mess_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=187;

--
-- AUTO_INCREMENT для таблицы `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT для таблицы `products_group`
--
ALTER TABLE `products_group`
  MODIFY `group_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `projects`
--
ALTER TABLE `projects`
  MODIFY `pr_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT для таблицы `project_status`
--
ALTER TABLE `project_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT для таблицы `project_type`
--
ALTER TABLE `project_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `reports`
--
ALTER TABLE `reports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT для таблицы `tasks`
--
ALTER TABLE `tasks`
  MODIFY `task_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=107;

--
-- AUTO_INCREMENT для таблицы `user_to_firm`
--
ALTER TABLE `user_to_firm`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT для таблицы `user_to_project`
--
ALTER TABLE `user_to_project`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
